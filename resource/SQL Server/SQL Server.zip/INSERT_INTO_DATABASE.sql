﻿USE QuanLyRapPhim
GO

INSERT INTO LoaiPhim VALUES
('LP01', N'Kinh dị'),
('LP02', N'Hành động'),
('LP03', N'Tình cảm'),
('LP04', N'Kiếm hiệp cổ trang'),
('LP05', N'Khoa học viễn tưởng'),
('LP06', N'Tài liệu'),
('LP07', N'Phim hài'),
('LP08', N'Hoạt hình'),
('LP09', N'Nhạc kịch')

-- -----------------------------------

INSERT INTO PhongChieu VALUES
('PC01', N'Phòng 1', '2D'),
('PC02', N'Phòng 2', N'3D'),
('PC03', N'Phòng 3', N'3D'),
('PC04', N'Phòng 4', '2D'),
('PC05', N'Phòng 5', '2D'),
('PC06', N'Phòng 6', N'3D'),
('PC07', N'Phòng 7', N'3D'),
('PC08', N'Phòng 8', N'3D'),
('PC09', N'Phòng 9', N'3D'),
('PC10', N'Phòng 10', '2D'),
('PC11', N'Phòng 11', 'Electric'),
('PC12', N'Phòng 12', 'Curved Screen'),
('PC13', N'Phòng 13', N'Trắng đen'),
('PC14', N'Phòng 14', N'IMAX'),
('PC15', N'Phòng 15', N'IMAX'),
('PC16', N'Phòng 16', N'IMAX'),
('PC17', N'Phòng 17', N'IMAX'),
('PC18', N'Phòng 18', N'4D'),
('PC19', N'Phòng 19', N'4D'),
('PC20', N'Phòng 20', 'Curved Screen')
GO


INSERT INTO LoaiVe VALUES
('LV01', N'VIP 1 ghế', 200000),
('LV02', N'VIP 2 ghế', 300000),
('LV03', N'Thường 1 ghế', 100000),
('LV04', N'Thường 2 ghế', 180000),
('LV05', N'Khuyến mãi', 100000),
('LV06', N'Trẻ em dưới 12', 50000)
GO

-- 7h-9h, 10-12h, 13h-15h, 16h-18h, 19h-21h
INSERT INTO SuatChieu VALUES
('7:00 - 9:00'),
('10:00 - 12:00'),
('13:00 - 15:00'),
('16:00 - 18:00'),
('19:00 - 21:00')
GO

INSERT INTO NhanVien VALUES
('NV01', N'Nguyễn Thị Thùy An', '261546888', N'123 Hải Phòng, Đà Nẵng', 'thuyan993@gmail.com', '0907718993', '1998-06-15', 1),
('NV02', N'Trần Minh Tâm',  '352101245', N'K18/15 Tôn Đức Thắng, Đà Nẵng',  'minhtam17051998@gmail.com', '0369868741', '1998-05-17', 0),
('NV03', N'Lương Thị Hải',  '102025489', N'67 Ngô Quyền, Đà nẵng',  'luonghai1998@fpt.edu.vn', '+84778852110', '1998-10-21', 1),
('NV04', N'Phạm Thị Thanh Thảo',  '121245463', N'K635 Trần Cao Vân, Đà Nẵng',  'thanhthao30@gmail.com', '0908851220', '1998-03-30', 1),
('NV05', N'Nguyễn Minh Khải',  '185475200', N'11 Trường chinh, Cẩm lệ, Đà nẵng',  'minhkhainguyen1231@gmail.com', '0306620001', '1998-12-31', 0),
('NV06', N'Nguyễn Tiến Thành',  '285413203', N'K101/22 Ngô Quyền, Hòa Minh, TP.HCM',  'tienthanh1999@fpt.edu.vn', '+84809963000', '1999-10-22', 0),
('NV07', N'Phan Công Danh',  '221451263', N'122 Trần Quang Giáp, Cần Thơ',  'congdanh160699@yahoo.com', '+84978874551', '1999-06-16', 0),
('NV08', N'Phạm Quang Sáng',  '200012100', N'54 Nguyễn Quang Diệu, TP.Nha Trang',  'quangsang17@gmail.com', '0718845669', '1999-06-17', 0),
('NV09', N'Mai Tiến Luật',  '201200036', N'K54/180 Trần Liêu, TP.HCM',  'abc@gmail.com', '+84632323632', '1999-08-23', 0),
('NV10', N'Mai Quốc Hoan',  '145569999', N'Hẻm 142 Ngô Đình Thái, TP.Hà Nội',  'maiquochoan1997@gmail.com', '+84620014777', '1997-08-05', 0),
('NV11', N'Phùng Thị Thu Hiền',  '151548403', N'Hà Nội',  'superman@gmail.com', '09087745448', '1997-07-07', 1),
('NV12', N'Phan Thị Thục Trinh',  '163250032', N'54 Hồ Hoàn Kiếm, TP.Hà Nội',  'thuctrinh1171997@gmail.com', '0918563969', '1997-07-11', 1),
('NV13', N'Đoàn Triệu Vĩnh',  '124563331', N'K78/15 Lê Hoàng, TP.Đà Nẵng',  'trieuvinh@gmail.com', '0845565454', '1997-06-11', 0),
('NV14', N'Lê Nguyễn Lan Hương',  '201796161', N'Lê Độ, TP.Đà nẵng',  'huonglnlpd04867@fpt.edu.vn', '0512203693', '1992-11-01', 0),
('NV15', N'Trương Thị Thanh Danh',  '199986512', N'569 Hàm nghi, Hải châu, Đà nẵng',  'thanhdanh26@gmail.com', '+84787787889', '1992-09-26', 1),
('NV16', N'Trương Minh Hiếu',  '261544147', N'96 Trương định, Cần thơ',  'minhhieu3009@gmail.com', '+84969963660', '1993-09-30', 0),
('NV17', N'Nguyễn Ngọc Kha',  '261546755', N'541/56 Lý thái tông, Thanh khê, TP.Đà nẵng',  'nguyenkhait220699@gmail.com', '0386837394', '1999-06-22', 0)
GO


INSERT INTO TaiKhoan VALUES
('NV01', '0918257468', 1),
('NV02', '123456a', 0),
('NV03', 'hai123456', 0),
('NV04', 'thanhthao3003', 0),
('NV05', '15225478', 0),
('NV06', 'tienthanh', 0),
('NV07', '0907718993', 1),
('NV08', '123456S', 0),
('NV09', '1111000', 0),
('NV10', '79797979', 0),
('NV11', 'idontknow', 0),
('NV12', 'khongthich', 0),
('NV13', 'trieuvinh26', 0),
('NV14', '123456', 0),
('NV15', '96cantho', 0),
('NV16', '123456789', 1),
('NV17', '0907718993', 1)
GO

