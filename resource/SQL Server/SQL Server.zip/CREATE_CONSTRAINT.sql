CREATE DATABASE QuanLyRapPhim
GO

USE QuanLyRapPhim
GO

CREATE TABLE ChiTietChoNgoi(
	MaChoNgoi int primary key not null,
	KieuChoNgoi nvarchar(15) not null,
	MaPhong char(10) not null
)
GO

CREATE TABLE ChiTietPhongChieu(
	MaChoNgoi int not null,
	IDChiTietCP int not null,
	MaVe int not null,
	[Status] nvarchar(20) not null
)
GO



CREATE TABLE KhachHang(
	MaKH char(10) primary key not null,
	HoTen nvarchar(100) not null,
	SDT char(13) not null UNIQUE,
	DiemTichLuy int DEFAULT 0
)
 GO

CREATE TABLE NhanVien(
	MaNV char(10) primary key not null,
	HoTen nvarchar(100) not null,
	CMND varchar(9) not null UNIQUE,
	DiaChi nvarchar(100) not null,
	Email varchar (100) not null,
	SDT char(13) not null UNIQUE,
	NgaySinh date not null,
	GioiTinh bit not null,
	SoLan int check(SoLan between 0 and 3) not null
)
 GO

 CREATE TABLE TaiKhoan (
	MaNV char(10) not null,
	MatKhau char(20) not null,
	VaiTro bit not null
 )
 GO

CREATE TABLE PhongChieu(
	MaPhong char(10) primary key not null,
	TenPhong nvarchar(100) not null,
	LoaiManHinh nvarchar(100) not null,
	TongSoChoNgoi int DEFAULT 200
)
 GO

 CREATE TABLE Phim(
	MaPhim char(10) primary key not null,
	MaLP char(10) not null,
	TenPhim nvarchar(100) not null,
	NSX datetime not null,
	DaoDien nvarchar(100) not null,
	HinhAnh nvarchar(100) not null,
	NgayCongChieu date not null,
	NgayHetHan date not null,
	ThoiLuong int not null
)
 GO

 CREATE TABLE LoaiPhim(
	MaLP char(10) primary key not null,
	LoaiPhim nvarchar(100) not null
)
 GO



CREATE TABLE Ve(
	MaVe int primary key IDENTITY(1,1) NOT NULL,
	MaPhim char(10) not null,
	MaLP char(10) not null,
	MaKH char(10) not null,
	MaLV char(10) not null,
	MaNV char(10) not null,
	MaSoGhe int,
	NgayBanVe datetime default getdate()
)
GO

  -- ------------------------------------------


CREATE TABLE LoaiVe(
	MaLV char(10) primary key not null,
	TenLV nvarchar(20) not null,
	DonGia int
)
 GO


CREATE TABLE ChiTietChieuPhim(
	MaCTCP int primary key not null IDENTITY(1,1),
	MaVe int not null,
	MaPhong char(10) not null,
	MaPhim char(10) not null,
	MaSC int not null
)
 GO

 CREATE TABLE SuatChieu (
	MaSC int IDENTITY (1,1) primary key not null check (MaSC <= 5),
	ThoiGianChieu varchar(15) not null
 )
 GO


 ALTER TABLE Ve
 ADD CONSTRAINT FK_Ve_LV FOREIGN KEY (MaLV) REFERENCES LoaiVe(MaLV) ON DELETE CASCADE ON UPDATE CASCADE;
  ALTER TABLE Ve
 ADD CONSTRAINT FK_Ve_NV FOREIGN KEY (MaNV) REFERENCES NhanVien(MaNV);
  ALTER TABLE Ve
 ADD CONSTRAINT FK_Ve_KH FOREIGN KEY (MaKH) REFERENCES KhachHang(MaKH);

  ALTER TABLE Phim
 ADD CONSTRAINT FK_Phim_LP FOREIGN KEY (MaLP) REFERENCES LoaiPhim(MaLP) ON DELETE CASCADE ON UPDATE CASCADE;


  ALTER TABLE ChiTietChieuPhim
 ADD CONSTRAINT FK_Chitiet_Ve FOREIGN KEY (MaVe) REFERENCES Ve(MaVe);
  ALTER TABLE ChiTietChieuPhim
 ADD CONSTRAINT FK_Chitiet_Phong FOREIGN KEY (MaPhong) REFERENCES PhongChieu(MaPhong);
  ALTER TABLE ChiTietChieuPhim
 ADD CONSTRAINT FK_Chitiet_Phim FOREIGN KEY (MaPhim) REFERENCES Phim(MaPhim);
   ALTER TABLE ChiTietChieuPhim
 ADD CONSTRAINT FK_Chitiet_SC FOREIGN KEY (MaSC) REFERENCES SuatChieu(MaSC);

 ALTER TABLE TaiKhoan
ADD CONSTRAINT FK_MaNV_NV_TK FOREIGN KEY (MaNV) REFERENCES NhanVien(MaNV);



 ALTER TABLE ChiTietChoNgoi
ADD CONSTRAINT FK_MaPhong_CTCN_PC FOREIGN KEY (MaPhong) REFERENCES PhongChieu(MaPhong);

 ALTER TABLE ChiTietPhongChieu
ADD CONSTRAINT FK_MaCTCP_CTPC_CTCP FOREIGN KEY (IDChiTietCP) REFERENCES ChiTietChieuPhim(MaCTCP);

 ALTER TABLE ChiTietPhongChieu
ADD CONSTRAINT FK_MaVe_CTPC_V FOREIGN KEY (MaVe) REFERENCES Ve(MaVe);


ALTER TABLE PhongChieu
ADD TongSoChoNgoi int DEFAULT 200